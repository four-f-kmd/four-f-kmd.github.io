
WinObjEx - Windows Object Explorer

Let you browse the Windows NT Object Manager namespace.

Tested on W2K, XP, W2K3.

Please, feel free to send me a bug report.

Please, let me know if you know something about the following object types:
  DebugObject
  FilterCommunicationPort
  FilterConnectionPort
  WmiGuid
__________________________________________
Copyright 2003-2005 Four-F, four-f@mail.ru