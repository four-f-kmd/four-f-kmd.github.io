
I/O Control Code Decoder

Did you ever try to understand what does the code similar to this:

; IO_STACK_LOCATION.Parameters.DeviceIoControl.IoControlCode
:00010407  mov     eax, [edi+0Ch]
:0001040A  sub     eax, 70000h     ; 00070000
:0001040F  jz      loc_106E9
:00010415  sub     eax, 14h        ; 00070014
:00010418  jz      loc_10661
:0001041E  sub     eax, 10h        ; 00070024
:00010421  jz      loc_105E3
:00010427  sub     eax, 0BDCh      ; 00070C00
:0001042C  jz      loc_1050D
:00010432  sub     eax, 3404h      ; 00074004
:00010437  jz      short loc_104B8
:00010439  sub     eax, 8014h      ; 0007C018
:0001043E  jnz     loc_104F6

If you did you probably noticed that it's not so easy
as may seem at the first glance. With the help of
IoctlDecoder.exe it's much more easier.


Note1: IoctlDecoder displays only basic Device Type. So, for example,
instead of IOCTL_SCSI_BASE you will see FILE_DEVICE_CONTROLLER,
and instead of FSCTL_IP_BASE - FILE_DEVICE_NETWORK etc...
This is because of the following definitions:

IOCTL_SCSI_BASE	equ FILE_DEVICE_CONTROLLER
FSCTL_IP_BASE	equ FILE_DEVICE_NETWORK


Note2: IoctlDecoder can't recognize (few exceptions), for example, between
IOCTL_SERIAL_SET_BAUD_RATE and IOCTL_SERIAL_INTERNAL_DO_WAIT_WAKE
because their definitions are the same:

IOCTL_SERIAL_SET_BAUD_RATE
   equ CTL_CODE(FILE_DEVICE_SERIAL_PORT, 1, METHOD_BUFFERED, FILE_ANY_ACCESS)
IOCTL_SERIAL_INTERNAL_DO_WAIT_WAKE
   equ CTL_CODE(FILE_DEVICE_SERIAL_PORT, 1, METHOD_BUFFERED, FILE_ANY_ACCESS)

So you will be able to decode only the first one. Probably in the future releases
I will figure out how to fix this problem.
______________________
Four-F, four-f@mail.ru